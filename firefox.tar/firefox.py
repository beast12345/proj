#!/usr/bin/python

import  commands
commands.getoutput('ssh -X  rohit@192.168.10.59  firefox')

